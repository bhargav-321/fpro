package com.pzone.ank.common;

import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Nullable;

import com.google.common.base.Preconditions;

public class AnkLock {

  private final Object                     lock;

  private final Map<Object, ObjectCounter> locks;

  public AnkLock() {
    this.lock = new Object();
    this.locks = new HashMap<>();
  }

  public ObjectCounter lock(Object object) {
    synchronized (lock) {
      @Nullable ObjectCounter l = this.locks.get(object);
      if (l == null) {
        l = new ObjectCounter(this, object);
        this.locks.put(object, l);
      } else {
        l.getCounter().incrementAndGet();
      }

      return l;
    }
  }

  public <R> R lockAndRun(Object object, PzLockFunction<R> function) throws Exception {
    try (final ObjectCounter lc = lock(object)) {
      synchronized (lc) {
        return function.execute();
      }
    }
  }

  public void unlock(Object object) {
    synchronized (lock) {
      final ObjectCounter l = this.locks.get(object);
      if (l == null) {
        throw new IllegalArgumentException("There are no lock available for the key " + object);
      }

      l.getCounter().decrementAndGet();
      if (l.getCounter().get() == 0)
        this.locks.remove(object);

    }
  }

  public final static class ObjectCounter implements Closeable {

    private final AnkLock       locks;
    private final AtomicInteger counter;
    private final Object        object;

    public ObjectCounter(AnkLock locks, Object o) {
      this.locks = Preconditions.checkNotNull(locks, "lock should not be null");
      this.counter = new AtomicInteger(1);
      this.object = Preconditions.checkNotNull(o, "object should not be null");
    }

    public AnkLock getLocks() {
      return locks;
    }

    public AtomicInteger getCounter() {
      return counter;
    }

    public Object getObject() {
      return object;
    }

    @Override
    public void close() {
      locks.unlock(object);
    }
  }

  public static interface PzLockFunction<R> {
    public R execute() throws Exception;
  }
}