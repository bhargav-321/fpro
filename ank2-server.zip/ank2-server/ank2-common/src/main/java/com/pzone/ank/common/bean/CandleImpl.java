package com.pzone.ank.common.bean;

import java.io.Serializable;

import com.google.common.base.Preconditions;

public class CandleImpl implements Candle, Serializable {

  private static final long serialVersionUID = 1L;
  private String            key;
  private CandleDuration    duration;

  private Integer           tc;                   // tick counter
  private Double            o;
  private Double            h;
  private Double            l;
  private Double            c;

  private Double            ov;
  private Double            cv;

  private Double            oio;
  private Double            oih;
  private Double            oil;
  private Double            oic;

  private Long              opTime;
  private Long              clTime;

  CandleImpl() {
  }

  public CandleImpl(String key, CandleDuration duration) {
    Preconditions.checkNotNull(key, "key can't be null");
    Preconditions.checkNotNull(duration, "duration can't be null");

    this.key = key;
    this.duration = duration;
  }

  public void addTick(TickRow row) {
    Preconditions.checkNotNull(row, "row can't be null");
    Preconditions.checkArgument(duration == CandleDuration.M1, "Tick only support M1 candles");

    if (tc == 0)
      opTime = Candle.roundTime(row.getTime());

    if (o == 0)
      this.o = row.getP();

    if (h == 0)
      this.h = row.getP();

    if (this.l == 0)
      this.l = row.getP();

    this.c = row.getP();
    this.h = Math.max(this.h, row.getP());
    this.l = Math.min(this.l, row.getP());

    if (this.ov == 0)
      this.ov = row.getV();

    this.cv = row.getV();

    if (oio == 0)
      this.oio = row.getOi();

    if (oih == 0)
      this.oih = row.getOi();

    if (this.oil == 0)
      this.oil = row.getOi();

    this.oic = row.getOi();
    this.oih = Math.max(this.oih, row.getOi());
    this.oil = Math.min(this.oil, row.getOi());
    this.clTime = Candle.roundTime(row.getTime());

    tc = tc + 1;
  }

  public void mergeCandle(Candle row) {
    if (this.o == 0)
      this.o = row.getO();

    if (this.h == 0)
      this.h = row.getH();

    if (this.l == 0)
      this.l = row.getL();

    this.c = row.getC();
    this.h = Math.max(this.h, row.getH());
    this.l = Math.min(this.l, row.getL());

    if (this.ov == 0)
      this.ov = row.getOv();

    this.cv = row.getCv();

    if (oio == 0)
      this.oio = row.getOio();

    if (oih == 0)
      this.oih = row.getOih();

    if (this.oil == 0)
      this.oil = row.getOil();

    this.oic = row.getOic();
    this.oih = Math.max(this.oih, row.getOih());
    this.oil = Math.min(this.oil, row.getOil());

    if (this.opTime == 0)
      this.opTime = row.getOpTime();

    this.clTime = row.getClTime();

    tc = tc + row.getTc();
  }

  void setKey(String key) {
    this.key = key;
  }

  void setTc(Integer tc) {
    this.tc = tc;
  }

  void setO(Double o) {
    this.o = o;
  }

  void setH(Double h) {
    this.h = h;
  }

  void setL(Double l) {
    this.l = l;
  }

  void setC(Double c) {
    this.c = c;
  }

  void setCv(Double cv) {
    this.cv = cv;
  }

  void setOv(Double ov) {
    this.ov = ov;
  }

  void setOio(Double oio) {
    this.oio = oio;
  }

  void setOih(Double oih) {
    this.oih = oih;
  }

  void setOil(Double oil) {
    this.oil = oil;
  }

  void setOic(Double oic) {
    this.oic = oic;
  }

  void setDuration(CandleDuration duration) {
    this.duration = duration;
  }

  void setOpTime(Long opTime) {
    this.opTime = opTime;
  }

  void setClTime(Long clTime) {
    this.clTime = clTime;
  }

  public Integer getTc() {
    return tc;
  }

  public Double getO() {
    return o;
  }

  public Double getH() {
    return h;
  }

  public Double getL() {
    return l;
  }

  public Double getC() {
    return c;
  }

  public Double getOio() {
    return oio;
  }

  public Double getOih() {
    return oih;
  }

  public Double getOil() {
    return oil;
  }

  public Double getOic() {
    return oic;
  }

  public String getKey() {
    return key;
  }

  public Double getOv() {
    return ov;
  }

  public Double getCv() {
    return cv;
  }

  public CandleDuration getDuration() {
    return duration;
  }

  public Long getClTime() {
    return clTime;
  }

  public Long getOpTime() {
    return opTime;
  }
}
