package com.pzone.ank.common.bean;

import org.springframework.context.ApplicationEvent;

public class CandleEvent extends ApplicationEvent {

  private static final long serialVersionUID = 1L;

  public CandleEvent(Candle source) {
    super(source);
  }

  public Candle getCandle() {
    return (Candle) getSource();
  }
}
