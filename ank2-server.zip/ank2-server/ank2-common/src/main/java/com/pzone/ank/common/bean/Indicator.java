package com.pzone.ank.common.bean;

import java.io.Serializable;

import org.ta4j.core.num.Num;

public interface Indicator extends Serializable {

  public int getCandleSize();

  public CandleDuration getCandleDuration();

  public CandleField getCandleField();

  public Num calculate(String key, CandleBarCache cache);

}
