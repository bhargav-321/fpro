package com.pzone.ank.common.bean;

import java.util.List;

import org.ta4j.core.BarSeries;

public interface CandleBarCache {

  public List<Candle> getCandles(String key, CandleDuration duration, int candleSize);

  public BarSeries getBarSeries(String key, CandleDuration duration);

}
