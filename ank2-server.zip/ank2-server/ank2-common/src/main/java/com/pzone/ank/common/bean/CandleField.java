package com.pzone.ank.common.bean;

import org.ta4j.core.BarSeries;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.helpers.HighPriceIndicator;
import org.ta4j.core.indicators.helpers.LowPriceIndicator;
import org.ta4j.core.indicators.helpers.OpenPriceIndicator;
import org.ta4j.core.indicators.helpers.PriceIndicator;

public enum CandleField {

    OPEN,
    HIGH,
    LOW,
    CLOSE;

  public PriceIndicator getPriceIndicator(BarSeries series) {
    switch (this) {
    case OPEN:
      return new OpenPriceIndicator(series);

    case HIGH:
      return new HighPriceIndicator(series);

    case LOW:
      return new LowPriceIndicator(series);

    case CLOSE:
      return new ClosePriceIndicator(series);

    default:
      throw new IllegalArgumentException("Not yet defined " + this);
    }
  }

}
