package com.pzone.ank.common;

import java.text.DecimalFormat;

public class Utils {

  public final static DecimalFormat ROUND_FORMATTER = new DecimalFormat("#.##");

  public static double roundTwoDecimals(double d) {
    return Double.valueOf(ROUND_FORMATTER.format(d));
  }

}
