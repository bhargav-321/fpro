package com.pzone.ank.common.bean;

public interface TickRow extends Comparable<TickRow> {

  public String getKey();

  public Long getTime();

  public Double getP(); // price

  public Double getV(); // volume

  public Double getOi(); // Open interests

}
