package com.pzone.ank.common.bean;

import java.time.Duration;

public enum CandleDuration {

    M1 (1),
    M2 (2),
    M3 (3),
    M5 (5),
    M10 (10),
    M15 (15),
    M30 (30),
    M60 (60),
    M120 (120),
    M240 (240),
    M300 (300),
    D1 (1),
    W1 (1);

  private final int value;

  CandleDuration(int value) {
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  public Duration toDuration() {
    if (this.name().startsWith("M"))
      return Duration.ofMinutes(value);
    else if (this.name().startsWith("D"))
      return Duration.ofDays(value);
    else if (this.name().startsWith("W"))
      return Duration.ofDays(value * 7);
    else
      throw new IllegalArgumentException("NOT Implemented");
  }
}
