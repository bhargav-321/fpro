package com.pzone.ank.common;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;

import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.Uninterruptibles;

public class Blocker {

  private static final Logger LOG          = LogManager.getLogger(Blocker.class);

  private AtomicLong          counter      = new AtomicLong(0);

  private volatile boolean    error        = false;
  private volatile String     errorMsg     = null;

  private volatile int        maxTasksSize = -1;

  public Blocker() {
  }

  public Blocker(int maxTaskSize) {
    Preconditions.checkArgument(maxTaskSize > 0, "maxTaskSize must be > 0");
    this.maxTasksSize = maxTaskSize;
  }

  public void markError() {
    this.error = true;
  }

  public void markError(String msg) {
    this.error = true;

  }

  public void register() {
    lock();
  }

  public void arrive() {
    unlock();
  }

  public void await() {
    await(30);
  }

  public long getTaskCount() {
    return this.counter.get();
  }

  public void await(int printInfoDurationInMins) {
    DateTime startTime = new DateTime();
    while (true) {
      if (this.error) {
        if (this.errorMsg == null)
          LOG.info("Skipping counter due to error is set");
        else
          LOG.info("Skipping counter due to error {}", errorMsg);

        break;
      }

      if (counter.get() == 0) {
        break;
      }

      if (printInfoDurationInMins > 0) {
        if ((System.currentTimeMillis() - startTime.getMillis()) > TimeUnit.MINUTES.toMillis(printInfoDurationInMins)) {
          LOG.info("Still {} tasks to finish...", counter.get());
          startTime = new DateTime();
        }
      }

      Uninterruptibles.sleepUninterruptibly(5, TimeUnit.MILLISECONDS);
    }
  }

  private void lock() {
    synchronized (counter) {
      if (maxTasksSize > 0) {
        while (counter.get() > maxTasksSize) {
          try {
            counter.wait();
          } catch (InterruptedException e) {
          }
        }
      }

      counter.incrementAndGet();
      counter.notifyAll();
    }
  }

  private void unlock() {
    synchronized (counter) {
      counter.decrementAndGet();
      counter.notifyAll();
    }
  }
}
