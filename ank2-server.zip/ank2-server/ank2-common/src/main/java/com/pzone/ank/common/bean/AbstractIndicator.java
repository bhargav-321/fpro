package com.pzone.ank.common.bean;

import java.util.List;

import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeries;
import org.ta4j.core.indicators.helpers.PriceIndicator;
import org.ta4j.core.num.Num;

import com.google.common.base.Preconditions;

public abstract class AbstractIndicator implements Indicator {

  private static final long serialVersionUID = 1L;

  private CandleDuration    candleDuration;

  private Integer           candleSize;

  private CandleField       candleField;

  public AbstractIndicator(CandleDuration candleDuration, Integer candleSize, CandleField candleField) {
    this.candleDuration = Preconditions.checkNotNull(candleDuration, "candleDuration must bot be null");
    Preconditions.checkArgument(candleSize > 0, "candleSize has to be > 0");
    this.candleSize = candleSize;
    this.candleField = Preconditions.checkNotNull(candleField, "candleFilds must bot be null");
  }

  void setCandleDuration(CandleDuration candleDuration) {
    this.candleDuration = candleDuration;
  }

  void setCandleSize(Integer candleSize) {
    this.candleSize = candleSize;
  }

  void setCandleField(CandleField candleField) {
    this.candleField = Preconditions.checkNotNull(candleField, "candleFilds must bot be null");
  }

  @Override
  public CandleField getCandleField() {
    return candleField;
  }

  @Override
  public CandleDuration getCandleDuration() {
    return candleDuration;
  }

  @Override
  public int getCandleSize() {
    return candleSize;
  }

  @Override
  public Num calculate(String key, CandleBarCache cache) {
    final BarSeries barSeries = cache.getBarSeries(key, getCandleDuration());
    final PriceIndicator pi = getCandleField().getPriceIndicator(barSeries);
    return calculateValue(cache, pi, barSeries);
  }

  public BarSeries toBarSeries(List<Candle> candles) {
    final BarSeries bs = new BaseBarSeries();
    for (Candle c : candles)
      bs.addBar(c.toBar());

    return bs;
  }

  public abstract Num calculateValue(CandleBarCache cache, PriceIndicator indicator, BarSeries barSeries);
}
