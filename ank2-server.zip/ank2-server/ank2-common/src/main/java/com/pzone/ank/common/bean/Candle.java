package com.pzone.ank.common.bean;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import org.ta4j.core.Bar;
import org.ta4j.core.BaseBar;

public interface Candle {

  public Double getO();

  public Double getH();

  public Double getL();

  public Double getC();

  public Double getOv(); // open volume

  public Double getCv(); // close volume

  public Double getOio(); // OI Open

  public Double getOih(); // OI High

  public Double getOil(); // OI Low

  public Double getOic(); // OI Close

  public Integer getTc();

  public Long getOpTime();

  public Long getClTime();

  public String getKey();

  public CandleDuration getDuration();

  public default Bar toBar() {
    final ZonedDateTime t = ZonedDateTime.ofInstant(Instant.ofEpochMilli(getClTime()), ZoneId.systemDefault());
    return new BaseBar(getDuration().toDuration(), t, getO(), getH(), getL(), getC(), getCv());
  }

  public static long roundTime(long time) {
    return 1000 * (time / 1000);
  }
}
