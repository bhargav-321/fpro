package com.pzone.ank.common.bean;

public enum IndicatorType {

    RSI,
    ACCELERATION_DECELERATION,
    AROON_DOWN,
    AROON_OSCILLATOR,
    AROON_UP,
    ATR,
    AWESOME_OSCILLATOR;
}
