package com.pzone.ank.common;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.google.common.base.Preconditions;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

@Service
public class TimerService {
  private static final Logger            LOG = LogManager.getLogger(TimerService.class);

  private Cache<String, JobTimerBuilder> timers;

  @PostConstruct
  private void init() {
    this.timers = CacheBuilder.newBuilder().build();
    Executors.newSingleThreadScheduledExecutor().scheduleWithFixedDelay(new Runnable() {
      @Override
      public void run() {
        try {
          final String text = printTimer();
          if (text.isEmpty())
            return;

          LOG.info("\n{}", text);
        } catch (Exception e) {
          LOG.error("Failed to print timer", e);
        }
        printTimer();
      }
    }, 1, 1, TimeUnit.MINUTES);
  }

  public String printTimer() {
    final StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, JobTimerBuilder> entry : timers.asMap().entrySet()) {
      final String export = entry.getValue().toString();
      if (!export.isEmpty())
        sb.append(String.format("%-30.30s ", entry.getKey()) + entry.getValue().toString() + "\n");
    }

    return sb.toString();
  }

  public JobTimerBuilder newJobTimerFor(String processor) {
    try {
      return timers.get(processor, new Callable<JobTimerBuilder>() {
        @Override
        public JobTimerBuilder call() throws Exception {
          return new JobTimerBuilder();
        }
      });
    } catch (ExecutionException e) {
      LOG.error("Failed to create new timer", e);
    }

    return new JobTimerBuilder();
  }

  public JobTimerBuilder newJobTimerFor(Class<?> cls) {
    return newJobTimerFor(cls.getName());
  }

  public static class JobTimerBuilder {

    private Cache<String, JobTimer> timers;

    private JobTimerBuilder() {
      this.timers = CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.MINUTES).build();
    }

    public JobTimer newTimer() {
      final JobTimer t = new JobTimer(UUID.randomUUID().toString());
      this.timers.put(t.id, t);
      return t;
    }

    @Override
    public String toString() {
      final StringBuilder sb = new StringBuilder();
      final List<JobTimer> activeTimers = new ArrayList<>();
      final DescriptiveStatistics stat = new DescriptiveStatistics();

      for (Map.Entry<String, JobTimer> entry : timers.asMap().entrySet()) {
        if (entry.getValue().isRunning()) {
          activeTimers.add(entry.getValue());
        } else if (entry.getValue().isInMinute()) {
          stat.addValue(((double) entry.getValue().totalTime()) / 1000d);
        } else {
          timers.invalidate(entry.getKey());
        }
      }

      if (stat.getValues().length > 0) {
        sb.append(String.format("Stat: %-5.4f [ %-5.4f - %-5.4f ], Count: %-6d/min",
          stat.getMean(),
          stat.getMin(),
          stat.getMax(),
          stat.getValues().length));
      }

      if (!activeTimers.isEmpty()) {
        if (sb.length() > 0)
          sb.append(", ");

        sb.append(String.format("Active jobs: %-6d", activeTimers.size()));
      }

      return sb.toString();
    }
  }

  public static class JobTimer implements Closeable {

    private final String id;

    private final long   startTime;

    private long         stopTime = -1;

    private JobTimer(String id) {
      this.id = Preconditions.checkNotNull(id);
      this.startTime = System.currentTimeMillis();
    }

    public void stop() {
      if (stopTime == -1)
        stopTime = System.currentTimeMillis();
    }

    public boolean isRunning() {
      return stopTime == -1;
    }

    public long totalTime() {
      return stopTime - startTime;
    }

    public boolean isInMinute() {
      return stopTime > 0 && (System.currentTimeMillis() - stopTime) <= TimeUnit.MINUTES.toMillis(1);
    }

    public String getId() {
      return id;
    }

    @Override
    public void close() {
      stop();
    }
  }
}
