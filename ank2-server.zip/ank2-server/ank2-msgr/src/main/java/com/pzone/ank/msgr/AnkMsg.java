package com.pzone.ank.msgr;

import java.io.Serializable;

public interface AnkMsg extends Serializable {

  public int getVersion();

  public String getKey();
}
