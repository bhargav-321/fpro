package com.pzone.ank.msgr;

import java.io.Closeable;
import java.time.Duration;
import java.util.Collection;
import java.util.HashSet;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.KafkaAdminClient;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Uninterruptibles;
import com.google.gson.Gson;

@Service
public class AnkMessenger {

  private static final Logger LOG    = LogManager.getLogger(AnkMessenger.class);

  @Autowired
  private Environment         environment;

  private String              appName;

  private Properties          adminProp;

  private Properties          prodProp;

  private Gson                gson;

  private Set<String>         msgTypeSet;

  private boolean             active = false;

  @PostConstruct
  private void init() {
    try {
      this.adminProp = new Properties();
      this.prodProp = new Properties();

      final String kafkaServerConfig = environment.getProperty("bootstrap.servers");
      if (kafkaServerConfig == null || kafkaServerConfig.trim().isEmpty()) {
        LOG.info("NOT CONNECTED WITH KAFKA... (missing bootstrap.servers property)");
        return;
      }

      this.active = true;
      this.appName = environment.getRequiredProperty("appName");
      Preconditions.checkArgument(!appName.trim().isEmpty(), "appName can't be empty");

      adminProp.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServerConfig);
      prodProp.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServerConfig);
      prodProp.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
      prodProp.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

      this.msgTypeSet = new HashSet<>();
      this.gson = new Gson();
    } catch (Exception e) {
      LOG.error("Failed to start kafka server", e);
      System.exit(1);
    }
  }

  public boolean isActive() {
    return active;
  }

  public void send(AnkMsg msg) {
    if (!active)
      return;

    send(getTopicName(msg.getClass()), msg);
  }

  private void checkAndCreateTopic(String topicName) {
    if (!this.msgTypeSet.contains(topicName)) {
      try (AdminClient adminClient = KafkaAdminClient.create(this.adminProp)) {
        final NewTopic topic = new NewTopic(topicName, 1, (short) 1);
        final Collection<NewTopic> newTopic = Lists.newArrayList(topic);
        final ListTopicsResult options = adminClient.listTopics();
        boolean exists = false;
        try {
          for (String name : options.names().get()) {
            if (name.equals(topicName)) {
              exists = true;
              break;
            }
          }
        } catch (Exception e) {
          LOG.error("Failed to check topics ", e);
        }

        if (!exists)
          adminClient.createTopics(newTopic);
        this.msgTypeSet.add(topicName);
      }
    }
  }

  private void send(String topic, AnkMsg msg) {
    checkAndCreateTopic(topic);
    try (final KafkaProducer<String, String> producer = new KafkaProducer<>(this.prodProp)) {
      producer.send(new ProducerRecord<String, String>(topic, gson.toJson(msg)));
    }
  }

  public <MSG extends AnkMsg> void listener(AnkMsgExecutor<? extends AnkMsg> executor) {
    final String topicName = getTopicName(executor.getClazz());
    if (!active) {
      LOG.warn("##### NOT ACTIVE MSGER #####, WON'T BE LISTENING TO TOPIC {}", topicName);
      return;
    }

    checkAndCreateTopic(topicName);
    Executors.newSingleThreadExecutor().execute(new Runnable() {
      @Override
      public void run() {
        while (true) {
          try {
            try (final AnkConsumer<? extends AnkMsg> consumer = new AnkConsumer<>(executor)) {
              consumer.execute();
            }
          } catch (Exception e) {
            LOG.error("Failed to create consumer ", e);
          }
          Uninterruptibles.sleepUninterruptibly(2, TimeUnit.SECONDS);
        }
      }
    });
  }

  private class AnkConsumer<T extends AnkMsg> implements Closeable {

    private final String                        topic;

    private final Properties                    consumerProp;

    private final AnkMsgExecutor<T>             msgExecutor;

    private final KafkaConsumer<String, String> consumer;

    private AnkConsumer(AnkMsgExecutor<T> msgExecutor) {
      try {
        this.msgExecutor = Preconditions.checkNotNull(msgExecutor);
        this.topic = getTopicName(msgExecutor.getClazz());
        this.consumerProp = new Properties();
        final String kafkaServerConfig = environment.getRequiredProperty("bootstrap.servers");
        final String appName = environment.getRequiredProperty("appName");
        Preconditions.checkArgument(!appName.trim().isEmpty(), "appName can't be empty");

        final StringBuilder sb = new StringBuilder();
        new Random().ints(1).sorted().forEach(sb::append);

        String hostname = environment.getProperty("hostname") + "-" + sb.toString();
        if (hostname == null || hostname.trim().isEmpty())
          hostname = new Random().nextInt() + "-hostname";

        final String kafkaGroupId = appName + "-" + hostname + "-" + this.topic;
        LOG.info("Initializing listener for group ID {}", kafkaGroupId);
        Thread.currentThread().setName(kafkaGroupId);

        consumerProp.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServerConfig);
        consumerProp.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerProp.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerProp.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        consumerProp.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 10000);
        consumerProp.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        consumerProp.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaGroupId);

        this.consumer = new KafkaConsumer<>(consumerProp);
        consumer.subscribe(Lists.newArrayList(topic));
        LOG.info("Consumer started for topic {}", topic);
      } catch (Exception e) {
        LOG.error("Failed to init listener, exiting", e);
        throw new RuntimeException(e);
      }
    }

    @SuppressWarnings("unchecked")
    public void execute() {
      while (true) {
        try {
          final ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(500));
          if (records != null && !records.isEmpty()) {
            records.forEach(r -> {
              try {
                final AnkMsg msg = gson.fromJson(r.value(), msgExecutor.getClazz());
                msgExecutor.execute((T) msg);
              } catch (Exception e) {
                LOG.error("Failed to process record {} ", r, e);
              }
            });
          }
        } catch (Exception e) {
          LOG.error("Failed to poll consumer {}", topic, e);
          break;
        }
      }
    }

    @Override
    public void close() {
      this.consumer.close();
    }
  }

  public static String getTopicName(Class<?> cls) {
    return cls.getSimpleName();
  }
}
