package com.pzone.ank.msgr.type;

import java.util.UUID;

import com.google.common.base.Preconditions;
import com.pzone.ank.common.bean.TickRow;
import com.pzone.ank.msgr.AnkMsg;

public class TickMsg implements AnkMsg {

  private static final long serialVersionUID = 1L;

  private final TickRow     tick;

  public TickMsg(TickRow tick) {
    this.tick = Preconditions.checkNotNull(tick);
  }

  public TickRow getTick() {
    return tick;
  }

  @Override
  public int getVersion() {
    return 0;
  }

  @Override
  public String getKey() {
    return UUID.randomUUID().toString();
  }
}
