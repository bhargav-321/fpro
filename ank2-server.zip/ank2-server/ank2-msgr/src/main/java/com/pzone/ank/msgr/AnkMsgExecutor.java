package com.pzone.ank.msgr;

public interface AnkMsgExecutor<MSG extends AnkMsg> {

  public void execute(MSG msg);

  public Class<MSG> getClazz();
}
