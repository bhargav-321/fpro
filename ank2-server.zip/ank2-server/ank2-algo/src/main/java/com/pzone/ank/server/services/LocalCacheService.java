package com.pzone.ank.server.services;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.ta4j.core.Bar;
import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeries;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import com.pzone.ank.common.bean.Candle;
import com.pzone.ank.common.bean.CandleBarCache;
import com.pzone.ank.common.bean.CandleDuration;
import com.pzone.ank.common.bean.CandleEvent;

@Service
public class LocalCacheService implements CandleBarCache {

  // private static final Logger LOG = LogManager.getLogger(LocalCacheService.class);

  private Table<String, CandleDuration, BarSeries> barSeries;

  @PostConstruct
  private void init() {
    dayOpen();// NEED TO CHANGE THIS LATER
  }

  @EventListener
  private void receiveCandle(CandleEvent candleEvent) {
    addCandle(candleEvent.getCandle());
  }

  public void dayOpen() {
    this.barSeries = HashBasedTable.create();
  }

  public void dayClose() {
    // NEED TO PERFOM DAY CLOSING ACTIVITY
    throw new RuntimeException("Not yet implemented");
  }

  @Override
  public List<Candle> getCandles(String key, CandleDuration duration, int candleSize) {
    throw new RuntimeException("Not yet implemented");
  }

  @Override
  public BarSeries getBarSeries(String key, CandleDuration duration) {
    synchronized (this.barSeries) {
      BarSeries s = barSeries.get(key, duration);
      if (s == null) {
        s = new BaseBarSeries(key);
        barSeries.put(key, duration, s);
      }

      return s;
    }
  }

  public void addCandle(Candle candle) {
    final Bar bar = candle.toBar();
    final String key = candle.getKey();
    final CandleDuration duration = candle.getDuration();

    synchronized (this.barSeries) {
      BarSeries s = barSeries.get(key, duration);
      if (s == null) {
        s = new BaseBarSeries(key);
        barSeries.put(key, duration, s);
      }

      s.addBar(bar);
    }
  }

}
