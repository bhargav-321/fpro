package com.pzone.ank.server;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(exclude = { CassandraDataAutoConfiguration.class })
@ComponentScan({ "com.pzone.ank" })
public class AnkServerApp {

  private static final Logger LOG = LogManager.getLogger(AnkServerApp.class);

  public static void main(String arr[]) {
    try {
      SpringApplication.run(AnkServerApp.class, arr);
    } catch (Exception e) {
      LOG.error("Failed to start application, ", e);
      System.exit(1);
    }

  }
}
