package com.pzone.ank.server.indicator;

import org.ta4j.core.BarSeries;
import org.ta4j.core.indicators.RSIIndicator;
import org.ta4j.core.indicators.helpers.PriceIndicator;
import org.ta4j.core.num.Num;

import com.pzone.ank.common.bean.AbstractIndicator;
import com.pzone.ank.common.bean.CandleBarCache;
import com.pzone.ank.common.bean.CandleDuration;
import com.pzone.ank.common.bean.CandleField;

public class RsiIndicator extends AbstractIndicator {

  private static final long serialVersionUID = 1L;

  public RsiIndicator(CandleDuration candleDuration, Integer candleSize, CandleField candleField) {
    super(candleDuration, candleSize, candleField);
  }

  @Override
  public Num calculateValue(CandleBarCache cache, PriceIndicator indicator, BarSeries barSeries) {
    final RSIIndicator ri = new RSIIndicator(indicator, getCandleSize());
    return ri.getValue(0);
  }
}
