package com.pzone.ank.server.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Nullable;
import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.LocalTime;
import org.joda.time.Minutes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import com.google.common.base.Preconditions;
import com.pzone.ank.common.Blocker;
import com.pzone.ank.common.bean.Candle;
import com.pzone.ank.common.bean.CandleDuration;
import com.pzone.ank.common.bean.CandleEvent;
import com.pzone.ank.common.bean.CandleImpl;
import com.pzone.ank.common.bean.TickRow;
import com.pzone.ank.msgr.AnkMessenger;
import com.pzone.ank.msgr.AnkMsgExecutor;
import com.pzone.ank.msgr.type.TickMsg;

@Service
public class MinsCandleBuildService {

  private static final Logger       LOG     = LogManager.getLogger(MinsCandleBuildService.class);

  private static final LocalTime    ST_TIME = new LocalTime(00, 00, 00);

  @Autowired
  private AnkMessenger              messenger;

  @Autowired
  private ApplicationEventPublisher publisher;

  private CandleBuilder             minCandle;
  private List<CandleBuilder>       minsCandles;

  private ExecutorService           executor;

  @PostConstruct
  private void init() {
    this.minCandle = new CandleBuilder(CandleDuration.M1);

    this.minsCandles = new ArrayList<CandleBuilder>();
    for (CandleDuration d : CandleDuration.values()) {
      if (!d.name().startsWith("M"))
        continue;

      if (d == CandleDuration.M1)
        continue;

      this.minsCandles.add(new CandleBuilder(d));
    }

    this.executor = Executors.newFixedThreadPool(this.minsCandles.size());

    if (!messenger.isActive())
      throw new IllegalArgumentException("Messenger service is not connected, can't run application");

    messenger.listener(new AnkMsgExecutor<TickMsg>() {
      @Override
      public void execute(TickMsg msg) {
        addTick(msg.getTick());
      }

      @Override
      public Class<TickMsg> getClazz() {
        return TickMsg.class;
      }
    });

    LOG.info("Candle builder initialised...");
  }

  public void addTick(TickRow row) {
    Preconditions.checkNotNull(row, "tickRow can't be null");

    @Nullable final Candle oneMinCan = minCandle.addTick(row);
    if (oneMinCan != null) {
      publisher.publishEvent(new CandleEvent(oneMinCan));

      final Blocker blocker = new Blocker();
      for (CandleBuilder cb : this.minsCandles) {
        blocker.register();
        this.executor.execute(new Runnable() {
          @Override
          public void run() {
            try {
              final Candle minsCan = cb.addMinCandle(oneMinCan);
              publisher.publishEvent(new CandleEvent(minsCan));
            } catch (Exception e) {
              LOG.error("Failed to process tick row ", e);
              blocker.markError(e.getMessage());
            } finally {
              blocker.arrive();
            }
          }
        });
      }

      blocker.await();
    }
  }

  private static class CandleBuilder {

    private final Map<String, CandleImpl> candles;
    private final CandleDuration          duration;

    private CandleBuilder(CandleDuration duration) {
      Preconditions.checkNotNull(duration, "duration can't be null");
      this.duration = duration;
      this.candles = new HashMap<>();
    }

    @Nullable
    private Candle addTick(TickRow row) {
      final String key = row.getKey();
      final long time = row.getTime();

      final CandleImpl c;
      synchronized (this.candles) {
        final CandleImpl last = this.candles.get(key);
        if (last == null) {
          c = new CandleImpl(key, duration);
          this.candles.put(key, c);
        } else
          c = last;
      }

      if (c.getOpTime() == 0 || c.getOpTime() == Candle.roundTime(time)) {
        c.addTick(row);
      } else {
        final CandleImpl cn = new CandleImpl(key, duration);
        cn.addTick(row);
        synchronized (this.candles) {
          this.candles.put(key, cn);
        }

        return c;
      }

      return null;
    }

    @Nullable
    private Candle addMinCandle(Candle row) {
      Preconditions.checkNotNull(row, "row can't be null");
      Preconditions.checkArgument(duration != CandleDuration.M1, "This does not support M1 candles received " + duration);
      Preconditions.checkArgument(duration.name().startsWith("M"), "Only minutes candle can be processed received " + duration);

      final String key = row.getKey();
      final long time = row.getOpTime();

      final CandleImpl c;
      synchronized (this.candles) {
        final CandleImpl last = this.candles.get(key);
        if (last == null) {
          c = new CandleImpl(key, duration);
          this.candles.put(key, c);
        } else
          c = last;
      }

      final int m = Minutes.minutesBetween(ST_TIME, new LocalTime(time)).getMinutes();
      final int val = Math.floorMod(m, duration.getValue());
      if (c.getOpTime() == 0 || val == 0) {
        c.mergeCandle(row);
      } else {
        final CandleImpl cn = new CandleImpl(key, duration);
        cn.mergeCandle(row);
        synchronized (this.candles) {
          this.candles.put(key, cn);
        }

        return c;
      }

      return null;
    }
  }
}
