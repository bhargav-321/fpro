package com.pzone.ank.server.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.YamlClientConfigBuilder;
import com.hazelcast.core.HazelcastInstance;
import com.pzone.ank.common.bean.TickRow;

// NEED TO IMPLEMENT LATERON
// FIX ME BY KARTIK
public class HazelcastCacheService {

  private static final Logger LOG       = LogManager.getLogger(HazelcastCacheService.class);

  private HazelcastInstance   instance;

  private volatile boolean    connected = false;

  // @Autowired
  // private TimerService timerService;

  @Autowired
  private Environment         env;

  @PostConstruct
  private void init() {
    try {
      final String file = env.getProperty("hzconfig");
      if (file != null) {
        LOG.info("Trying to connect with hazelcast cache using file {}", file);
        final ClientConfig b = new YamlClientConfigBuilder(file).build();
        this.instance = HazelcastClient.newHazelcastClient(b);
        this.connected = true;
        LOG.info("Successfully connected with hazelcast server");
      } else
        LOG.info("Not connected with hazelcast server");
    } catch (Exception e) {
      LOG.warn("Failed to connect with hazelcast cache", e);
      this.connected = false;
      throw new RuntimeException(e);
    }
  }

  public boolean connected() {
    return instance != null && this.connected;
  }

  private <T> List<T> getList(String name) {
    if (!connected())
      throw new IllegalArgumentException("Not connected with hazelcast");

    return instance.getList(name);
  }

  public void addTick(TickRow tickRow) {
    final String token = tickRow.getKey();
    final List<TickRow> ticks = getList(token);
    ticks.add(tickRow);
  }

  public List<TickRow> getTicks(String key, int size) {
    final List<TickRow> ticks = getList(key);
    if (ticks.size() == 0)
      return new ArrayList<TickRow>();

    if (ticks.size() < size)
      return new ArrayList<TickRow>(ticks);

    return new ArrayList<TickRow>(ticks.subList((ticks.size() - size), ticks.size()));
  }
}
